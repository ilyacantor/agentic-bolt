
import os, time, json, glob, duckdb, pandas as pd, yaml, warnings, threading, re
from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse, JSONResponse
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import google.generativeai as genai

DB_PATH = "registry.duckdb"
ONTOLOGY_PATH = "ontology/catalog.yml"
SCHEMAS_DIR = "schemas"
CONF_THRESHOLD = 0.70
AUTO_PUBLISH_PARTIAL = True

if os.getenv("GEMINI_API_KEY"):
    genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
else:
    print("⚠️ GEMINI_API_KEY not set. LLM proposals may be unavailable.")

EVENT_LOG: List[str] = []
GRAPH_STATE = {"nodes": [], "edges": [], "confidence": None, "last_updated": None}
SOURCES_ADDED: List[str] = []
ENTITY_SOURCES: Dict[str, List[str]] = {}
ontology = None

def log(msg: str):
    print(msg, flush=True)
    EVENT_LOG.append(msg)
    if len(EVENT_LOG) > 50:
        EVENT_LOG.pop(0)

def load_ontology():
    with open(ONTOLOGY_PATH, "r") as f:
        return yaml.safe_load(f)

def infer_types(df: pd.DataFrame) -> Dict[str, str]:
    mapping = {}
    for col in df.columns:
        series = df[col]
        if pd.api.types.is_integer_dtype(series):
            mapping[col] = "integer"
        elif pd.api.types.is_float_dtype(series):
            mapping[col] = "numeric"
        else:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    pd.to_datetime(series.dropna().head(50),
                                   format="%Y-%m-%d %H:%M:%S",
                                   errors="raise")
                mapping[col] = "datetime"
            except Exception:
                try:
                    pd.to_datetime(series.dropna().head(50), errors="coerce")
                    mapping[col] = "datetime"
                except Exception:
                    mapping[col] = "string"
    return mapping

def snapshot_tables_from_dir(source_key: str, dir_path: str) -> Dict[str, Any]:
    tables = {}
    for path in glob.glob(os.path.join(dir_path, "*.csv")):
        tname = os.path.splitext(os.path.basename(path))[0]
        df = pd.read_csv(path)
        tables[tname] = {
            "path": path,
            "schema": infer_types(df),
            "samples": df.head(8).to_dict(orient="records")
        }
    return tables

def register_src_views(con, source_key: str, tables: Dict[str, Any]):
    for tname, info in tables.items():
        path = info["path"]
        view_name = f"src_{source_key}_{tname}"
        con.sql(f"CREATE OR REPLACE VIEW {view_name} AS SELECT * FROM read_csv_auto('{path}')")

def mk_sql_expr(src: Any, transform: str):
    if isinstance(src, list):
        parts = " || ' ' || ".join([f"COALESCE({c}, '')" for c in src])
        return parts + " AS value"
    if transform.startswith("cast"):
        return f"CAST({src} AS DOUBLE) AS value"
    if transform.startswith("parse_timestamp"):
        return f"TRY_STRPTIME({src}, '%Y-%m-%d %H:%M:%S') AS value"
    if transform.startswith("lower") or transform == 'lower_trim':
        return f"LOWER(TRIM({src})) AS value"
    return f"{src} AS value"

@dataclass
class Scorecard:
    confidence: float
    blockers: List[str]
    issues: List[str]
    joins: List[Dict[str,str]]

def llm_propose(ontology: Dict[str, Any], source_key: str, tables: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not os.getenv("GEMINI_API_KEY"):
        return None
    sys = (
        "You are a data integration planner. Given an ontology and a set of new tables from a source system, "
        "produce a STRICT JSON plan with proposed mappings and joins.\n\n"
        "Output format (strict JSON!):\n"
        "{"
        '  "mappings": ['
        '    {"entity":"customer","source_table":"<table>", "fields":[{"source":"<col>", "onto_field":"customer_id", "confidence":0.92}]},'
        '    {"entity":"transaction","source_table":"<table>", "fields":[{"source":"<col>", "onto_field":"amount", "confidence":0.88}]}'
        "  ],"
        '  "joins": [ {"left":"<table>.<col>", "right":"<table>.<col>", "reason":"why"} ]'
        "}"
    )
    prompt = f"Ontology:\\n{json.dumps(ontology)}\\n\\nSourceKey: {source_key}\\nTables:\\n{json.dumps(tables)}\\nReturn ONLY JSON."
    try:
        resp = genai.GenerativeModel("gemini-1.5-flash").generate_content([{"role":"system","parts":[sys]}, {"role":"user","parts":[prompt]}])
        text = resp.text.strip()
        m = re.search(r"\\{.*\\}", text, re.DOTALL)
        if not m:
            return None
        return json.loads(m.group(0))
    except Exception as e:
        log(f"[LLM ERROR] {e}")
        return None

def heuristic_plan(ontology: Dict[str, Any], source_key: str, tables: Dict[str, Any]) -> Dict[str, Any]:
    mappings, joins = [], []
    key_fields = ["accountid","AccountId","KUNNR","CustomerID","CUST_ID","entityId","customerid","parentcustomerid","Id","CUST_ID"]
    email_fields = ["email","emailaddress1","Email","EMAIL"]
    amount_fields = ["amount","Amount","NETWR","TotalAmount","estimatedvalue","AMOUNT"]
    date_fields = ["createdon","CreatedDate","CloseDate","ERDAT","ORDER_DATE","tranDate","created_at","CREATED_AT","OrderDate","ORDER_DATE"]
    for tname, info in tables.items():
        cols = list(info["schema"].keys())
        cust = next((c for c in cols if c in key_fields or c.lower() in ["customer_id","cust_id","id","accountid","account_id"]), None)
        email = next((c for c in cols if c in email_fields or "email" in c.lower()), None)
        amount = next((c for c in cols if c in amount_fields or "amount" in c.lower() or "price" in c.lower()), None)
        datec = next((c for c in cols if c in date_fields or "date" in c.lower()), None)
        if cust or email:
            fields = []
            if cust: fields.append({"source": cust, "onto_field": "customer_id", "confidence": 0.85})
            if email: fields.append({"source": email, "onto_field": "email", "confidence": 0.8})
            mappings.append({"entity":"customer","source_table": f"{source_key}_{tname}", "fields": fields})
        if amount or datec:
            fields = []
            if amount: fields.append({"source": amount, "onto_field": "amount", "confidence": 0.82})
            if datec: fields.append({"source": datec, "onto_field": "order_date", "confidence": 0.8})
            mappings.append({"entity":"transaction","source_table": f"{source_key}_{tname}", "fields": fields})
    # naive joins on shared key names
    name_to_tables = {}
    for t, info in tables.items():
        for c in info["schema"].keys():
            name_to_tables.setdefault(c.lower(), []).append(t)
    for key in ["accountid","customerid","kunnr","cust_id","account_id","id"]:
        if key in name_to_tables and len(name_to_tables[key])>1:
            T = name_to_tables[key]
            for i in range(len(T)-1):
                joins.append({"left": f"{T[i]}.{key}", "right": f"{T[i+1]}.{key}", "reason": f"shared key {key}"})
    return {"mappings": mappings, "joins": joins}

def apply_plan(con, source_key: str, plan: Dict[str, Any]) -> Scorecard:
    issues, blockers, joins = [], [], []
    confs = []
    per_entity_views = {}
    for m in plan.get("mappings", []):
        ent = m["entity"]
        src_table = f"src_{m['source_table']}"
        selects = []
        for f in m["fields"]:
            onto = f["onto_field"]
            src = f["source"]
            confs.append(float(f.get("confidence", 0.75)))
            selects.append(f"{src} AS {onto}")
        if not selects:
            continue
        view_name = f"dcl_{ent}_{source_key}_{m['source_table'].split('_',1)[1]}"
        try:
            con.sql(f"CREATE OR REPLACE VIEW {view_name} AS SELECT {', '.join(selects)} FROM {src_table}")
            per_entity_views.setdefault(ent, []).append(view_name)
            GRAPH_STATE["edges"].append({"source": src_table, "target": f"dcl_{ent}", "label": f"{m['source_table']} → {ent}", "type": "mapping"})
        except Exception as e:
            blockers.append(f"{ent}: failed view {view_name}: {e}")
    for ent, views in per_entity_views.items():
        union_sql = " UNION ALL ".join([f"SELECT * FROM {v}" for v in views])
        try:
            con.sql(f"CREATE OR REPLACE VIEW dcl_{ent} AS {union_sql}")
            ENTITY_SOURCES.setdefault(ent, []).append(source_key)
        except Exception as e:
            blockers.append(f"{ent}: union failed: {e}")
    for j in plan.get("joins", []):
        joins.append({"left": j["left"], "right": j["right"], "reason": j.get("reason","")})
        GRAPH_STATE["edges"].append({
            "source": f"src_{source_key}_{j['left'].split('.')[0]}",
            "target": f"src_{source_key}_{j['right'].split('.')[0]}",
            "label": j["left"].split('.')[-1] + " ↔ " + j["right"].split('.')[-1],
            "type": "join"
        })
    conf = sum(confs)/len(confs) if confs else 0.8
    return Scorecard(confidence=conf, blockers=blockers, issues=issues, joins=joins)

def add_graph_nodes_for_source(source_key: str, tables: Dict[str, Any]):
    for t in tables.keys():
        node_id = f"src_{source_key}_{t}"
        label = f"{t} ({source_key.title()})"
        GRAPH_STATE["nodes"].append({"id": node_id, "label": label, "type": "source"})
    for ent in ["customer","transaction"]:
        if not any(n["id"] == f"dcl_{ent}" for n in GRAPH_STATE["nodes"]):
            GRAPH_STATE["nodes"].append({"id": f"dcl_{ent}", "label": f"{ent.title()} (Unified)", "type": "ontology"})

def preview_table(con, name: str, limit: int = 6) -> List[Dict[str,Any]]:
    try:
        return con.sql(f"SELECT * FROM {name} LIMIT {limit}").to_df().to_dict(orient="records")
    except Exception:
        return []

def connect_source(source_key: str) -> Dict[str, Any]:
    global ontology
    if ontology is None:
        ontology = load_ontology()
    schema_dir = os.path.join(SCHEMAS_DIR, source_key)
    if not os.path.isdir(schema_dir):
        return {"error": f"Unknown source '{source_key}'"}
    tables = snapshot_tables_from_dir(source_key, schema_dir)
    con = duckdb.connect(DB_PATH)
    register_src_views(con, source_key, tables)
    add_graph_nodes_for_source(source_key, tables)
    plan = llm_propose(ontology, source_key, tables)
    if not plan:
        plan = heuristic_plan(ontology, source_key, tables)
        log(f"I connected to {source_key.title()} (schema sample) and generated a heuristic plan.")
    else:
        log(f"I connected to {source_key.title()} (schema sample) and proposed mappings and joins.")
    score = apply_plan(con, source_key, plan)
    GRAPH_STATE["confidence"] = score.confidence
    GRAPH_STATE["last_updated"] = time.strftime("%I:%M:%S %p")
    SOURCES_ADDED.append(source_key)
    ents = ", ".join(sorted(tables.keys()))
    log(f"I found these entities: {ents}.")
    if score.joins:
        log("To connect them, I proposed joins like " + "; ".join([f"{j['left']} with {j['right']}" for j in score.joins]) + ".")
    if score.confidence >= CONF_THRESHOLD and not score.blockers:
        log(f"I am about {int(score.confidence*100)}% confident. I created unified views so you can now query across these sources.")
    elif AUTO_PUBLISH_PARTIAL and not score.blockers:
        log(f"I applied the mappings, but with some issues: {score.issues}")
    else:
        log("I paused because of blockers and did not publish.")
    previews = {"sources": {}, "ontology": {}}
    for t in tables.keys():
        previews["sources"][f"src_{source_key}_{t}"] = preview_table(con, f"src_{source_key}_{t}")
    for ent in ["customer","transaction"]:
        previews["ontology"][f"dcl_{ent}"] = preview_table(con, f"dcl_{ent}")
    return {"ok": True, "score": score.confidence, "previews": previews}

def reset_demo():
    global EVENT_LOG, GRAPH_STATE, SOURCES_ADDED, ENTITY_SOURCES, ontology
    EVENT_LOG = []
    GRAPH_STATE = {"nodes": [], "edges": [], "confidence": None, "last_updated": None}
    SOURCES_ADDED = []
    ENTITY_SOURCES = {}
    ontology = load_ontology()
    try:
        os.remove(DB_PATH)
    except FileNotFoundError:
        pass
    log("I reset the demo. Pick a source from the menu to add it.")

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def index():
    html = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>DCL Agent — Sources Demo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <style>
    body { font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial; margin: 0; background:#0b0f14; color:#e6eef5;}
    header { padding:16px 20px; display:flex; align-items:center; gap:12px; border-bottom:1px solid #1b2430; position:sticky; top:0; background:#0b0f14; z-index:10;}
    select, button { background:#121a24; color:#e6eef5; border:1px solid #2a3644; padding:8px 10px; border-radius:10px; }
    button.primary { background:#2563eb; border-color:#2563eb; }
    .wrap { display:grid; grid-template-columns: 1.1fr 1.4fr; gap:16px; padding:16px; }
    .card { background:#0d131b; border:1px solid #1b2430; border-radius:14px; padding:14px; }
    .title { font-weight:600; margin:0 0 8px 0; color:#cfe7ff; }
    #log { white-space:pre-line; line-height:1.45; color:#d6e2ee; }
    #cy { width:100%; height:520px; background:#0a0f15; border:1px solid #1b2430; border-radius:12px;}
    .badge { position:absolute; top:16px; right:16px; background:#142133; border:1px solid #29405b; color:#bfe1ff; padding:6px 10px; border-radius:10px; font-size:12px;}
    .badge.good { background:#0e2f1b; border-color:#1b5e2b; color:#bfffd0; }
    .badge.warn { background:#39250e; border-color:#7a4d14; color:#ffd3aa; }
    .badge.pause { background:#2c2c2c; border-color:#444; color:#ddd; }
    .controls { display:flex; gap:8px; align-items:center;}
    .timeline { font-size:13px; color:#b2c3d6;}
    .grid2 { display:grid; grid-template-columns: 1fr 1fr; gap:12px; }
    table { width:100%; border-collapse: collapse; }
    th, td { border-bottom:1px solid #1b2430; padding:6px 8px; font-size:13px; }
    th { color:#a8c7ff; text-align:left; }
    .pill { padding:2px 8px; border-radius:999px; border:1px solid #253144; font-size:12px; color:#b5cbe6; }
    .toggle { margin-left:auto; display:flex; gap:8px; align-items:center; }
  </style>
</head>
<body>
  <header>
    <div class="controls">
      <select id="source">
        <option value="dynamics">Connect Dynamics CRM (schema sample)</option>
        <option value="salesforce">Connect Salesforce (schema sample)</option>
        <option value="sap">Connect SAP ERP (schema sample)</option>
        <option value="netsuite">Connect NetSuite (schema sample)</option>
        <option value="legacy_sql">Connect Legacy SQL Server (schema sample)</option>
        <option value="snowflake">Connect Snowflake (schema sample)</option>
      </select>
      <button class="primary" onclick="addSource()">Add Source</button>
      <div class="toggle">
        <span>Before/After</span>
        <input type="checkbox" id="viewToggle" onchange="renderGraph()" />
      </div>
      <button onclick="resetDemo()">Reset</button>
    </div>
  </header>
  <div class="wrap">
    <div class="card">
      <h3 class="title">Narration</h3>
      <div id="log"></div>
      <div class="timeline" id="timeline"></div>
    </div>
    <div class="card" style="position:relative;">
      <h3 class="title">Graph</h3>
      <div id="cy"></div>
      <div id="badge" class="badge">Confidence: --</div>
    </div>
    <div class="card grid2">
      <div>
        <h3 class="title">Source Preview</h3>
        <div id="preview_sources"></div>
      </div>
      <div>
        <h3 class="title">Unified Preview</h3>
        <div id="preview_ontology"></div>
      </div>
    </div>
  </div>

  <script src="https://unpkg.com/cytoscape@3.26.0/dist/cytoscape.min.js"></script>
  <script>
    let state = {events: [], timeline: [], graph: {nodes:[], edges:[], confidence:null, last_updated:null}, preview:{sources:{}, ontology:{}}};
    let cy;

    function badgeClass(conf){
      if(conf===null) return "badge";
      if(conf >= 0.8) return "badge good";
      if(conf >= 0.6) return "badge warn";
      return "badge pause";
    }

    async function fetchState(){
      const r = await fetch('/state');
      state = await r.json();
      renderLog();
      renderGraph();
      renderPreviews();
    }

    function renderLog(){
      const logEl = document.getElementById('log');
      logEl.textContent = state.events.join("\\n");
      const tl = document.getElementById('timeline');
      tl.textContent = state.timeline.join(" • ");
      const badge = document.getElementById('badge');
      const conf = state.graph.confidence;
      badge.textContent = (conf!=null? `Confidence: ${Math.round(conf*100)}%` : "Confidence: --") + (state.graph.last_updated? `  •  Updated: ${state.graph.last_updated}`: "");
      badge.className = badgeClass(conf);
    }

    function renderGraph(){
      const before = !document.getElementById('viewToggle').checked;
      const nodes = state.graph.nodes.map(n => ({ data:{ id:n.id, label:n.label, type:n.type } }));
      const edges = state.graph.edges.filter(e => before ? e.type!=='mapping' : true).map(e => ({ data:{ source:e.source, target:e.target, label:e.label, type:e.type } }));
      if(!cy){
        cy = cytoscape({
          container: document.getElementById('cy'),
          elements: { nodes, edges },
          style: [
            { selector: 'node', style: { 'background-color': '#1f3b59', 'label': 'data(label)', 'color':'#e6eef5', 'text-valign':'center', 'text-halign':'center', 'font-size':'12px', 'width':'label', 'height':'label', 'padding':'10px', 'border-width':1, 'border-color':'#2a4868', 'shape':'round-rectangle' } },
            { selector: 'node[type="ontology"]', style: { 'background-color': '#1e5a3d', 'border-color':'#2c8a5b' } },
            { selector: 'edge', style: { 'width': 2, 'line-color': '#395575', 'target-arrow-shape': 'triangle', 'target-arrow-color': '#395575', 'curve-style': 'bezier', 'label':'data(label)', 'font-size':'10px', 'color':'#bcd3ea', 'text-background-color':'#0b0f14', 'text-background-opacity':1, 'text-background-padding':2 } },
            { selector: 'edge[type="join"]', style: { 'line-color':'#7c5cff', 'target-arrow-color':'#7c5cff' } }
          ],
          layout: { name: 'cose', animate: true }
        });
        cy.on('tap', 'node', async (evt) => {
          const id = evt.target.id();
          const r = await fetch('/preview?node=' + encodeURIComponent(id));
          const data = await r.json();
          renderTable('preview_sources', data.sources);
          renderTable('preview_ontology', data.ontology);
        });
      } else {
        cy.elements().remove();
        cy.add(nodes);
        cy.add(edges);
        cy.layout({ name:'cose', animate:true }).run();
      }
    }

    function renderTable(elId, tables){
      const el = document.getElementById(elId);
      if(!tables || Object.keys(tables).length===0) { el.innerHTML = "<div class='pill'>Click a node to preview data</div>"; return; }
      let html = "";
      for(const [name, rows] of Object.entries(tables)){
        if(!rows || rows.length==0){ continue; }
        const cols = Object.keys(rows[0]);
        html += `<div class='pill' style='margin:6px 0;'>${name}</div>`;
        html += "<table><thead><tr>" + cols.map(c=>`<th>${c}</th>`).join("") + "</tr></thead><tbody>";
        rows.forEach(r => { html += "<tr>" + cols.map(c=>`<td>${r[c]}</td>`).join("") + "</tr>"; });
        html += "</tbody></table>";
      }
      el.innerHTML = html || "<div class='pill'>No data</div>";
    }

    function renderPreviews(){
      renderTable('preview_sources', state.preview.sources);
      renderTable('preview_ontology', state.preview.ontology);
    }

    async function addSource(){
      const src = document.getElementById('source').value;
      await fetch('/connect?source='+encodeURIComponent(src));
      await fetchState();
    }
    async function resetDemo(){
      await fetch('/reset');
      await fetchState();
    }

    setInterval(fetchState, 5000);
    fetchState();
  </script>
</body>
</html>
    """
    return HTMLResponse(content=html)

@app.get("/state")
def state():
    return JSONResponse({
        "events": EVENT_LOG,
        "timeline": EVENT_LOG[-5:],
        "graph": GRAPH_STATE,
        "preview": {"sources": {}, "ontology": {}}
    })

@app.get("/connect")
def connect(source: str = Query(..., regex="^(dynamics|salesforce|sap|netsuite|legacy_sql|snowflake)$")):
    res = connect_source(source)
    return JSONResponse(res)

@app.get("/reset")
def reset():
    reset_demo()
    return JSONResponse({"ok": True})

@app.get("/preview")
def preview(node: Optional[str] = None):
    con = duckdb.connect(DB_PATH)
    sources, ontology_tables = {}, {}
    if node:
        try:
            if node.startswith("src_"):
                sources[node] = preview_table(con, node)
            elif node.startswith("dcl_"):
                ontology_tables[node] = preview_table(con, node)
        except Exception:
            pass
    else:
        for ent in ["customer","transaction"]:
            ontology_tables[f"dcl_{ent}"] = preview_table(con, f"dcl_{ent}")
    return JSONResponse({"sources": sources, "ontology": ontology_tables})
