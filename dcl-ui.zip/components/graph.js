let state = {events: [], timeline: [], graph: {nodes:[], edges:[], confidence:null, last_updated:null}, preview:{sources:{}, ontology:{}}};
let cy;

const CLOUD_X = 120;
const CLOUD_WIDTH = 320;
const CLOUD_HEIGHT = 280;
const OFFSET = 220;
const INITECH_X = CLOUD_X + CLOUD_WIDTH/2 + OFFSET;

function badgeClass(conf){
  if(conf===null) return "badge";
  if(conf >= 0.8) return "badge good";
  if(conf >= 0.6) return "badge warn";
  return "badge pause";
}

function renderLog(){
  const logEl = document.getElementById('log');
  logEl.textContent = state.events.join("\n");
  const conf = state.graph.confidence;
  const statusBadge = document.getElementById('statusBadge');
  const confText = conf != null ? `${Math.round(conf*100)}%` : '--';
  const updateText = state.graph.last_updated || '--';
  statusBadge.textContent = `LLM Calls: ${state.llm.calls} | Confidence: ${confText} | Updated: ${updateText}`;
  const llmBadge = document.getElementById('llmBadge');
  llmBadge.textContent = `LLM Calls: ${state.llm.calls} | Tokens: ~${state.llm.tokens}`;
}

function getGridPosition(nodeType, index) {
  const yStart = 120;
  const ySpacing = 90;
  return {
    x: nodeType === "source" ? CLOUD_X : INITECH_X,
    y: yStart + index * ySpacing
  };
}

function spotlightNode(nodeId) {
  const node = cy.getElementById(nodeId);
  if (!node || node.length === 0) return;
  node.animate({
    style: { 'border-color': '#f1c40f', 'border-width': 4 },
    duration: 400
  }).animate({
    style: { 'border-color': node.data('type') === 'source' ? '#4a90e2' : '#2ecc71', 'border-width': 1 },
    duration: 800
  });
}

function revealOntology() {
  const unifiedBlock = cy.getElementById('unified_block');
  if (unifiedBlock.length > 0) {
    unifiedBlock.animate({ style: { opacity: 0.15 }, duration: 600 });
  }
  cy.nodes('[type="ontology"]').forEach(node => {
    node.animate({ style: { opacity: 1 }, duration: 600 });
  });
  cy.edges('[type="mapping"]').forEach(edge => {
    edge.animate({ style: { opacity: 1 }, duration: 600 });
  });
}

function renderGraph(){
  const sourceNodes = state.graph.nodes.filter(n => n.type !== 'ontology');
  const ontologyNodes = state.graph.nodes.filter(n => n.type === 'ontology');
  
  const mappedSources = new Set(state.graph.edges.filter(e => e.type === 'mapping').map(e => e.source));
  const unmappedSources = sourceNodes.filter(n => !mappedSources.has(n.id));
  
  let ontologyNodesWithUnclassified = [...ontologyNodes];
  if (state.auto_ingest_unmapped && unmappedSources.length > 0) {
    if (!ontologyNodesWithUnclassified.find(n => n.id === 'dcl_unclassified')) {
      ontologyNodesWithUnclassified.push({ id: 'dcl_unclassified', label: 'Unclassified (Unified)', type: 'ontology_unclassified' });
    }
  }
  
  const nodes = [
    ...sourceNodes.map((n, idx) => ({ 
      data: { id: n.id, label: n.label, type: 'source' },
      position: getGridPosition('source', idx),
      locked: true
    })),
    ...ontologyNodesWithUnclassified.map((n, idx) => ({ 
      data: { id: n.id, label: n.label, type: n.type === 'ontology_unclassified' ? 'ontology_unclassified' : 'ontology' },
      position: getGridPosition('ontology', idx),
      locked: true
    }))
  ];
  
  let allEdges = [...state.graph.edges.filter(e => e.type !== 'source' && e.type !== 'join')];
  if (state.auto_ingest_unmapped && unmappedSources.length > 0) {
    unmappedSources.forEach(source => {
      allEdges.push({
        source: source.id,
        target: 'dcl_unclassified',
        label: 'auto-ingested',
        type: 'mapping',
        confidence: 50
      });
    });
  }
  
  const edges = allEdges.map(e => ({ data: { source: e.source, target: e.target, label: e.label, type: e.type, confidence: e.confidence || 85 } }));
  
  if(!cy){
    cy = cytoscape({
      container: document.getElementById('cy'),
      elements: [],
      style: [
        {
          selector: 'node[type="source"]',
          style: {
            'background-color': '#4a90e2',
            'label': 'data(label)',
            'color': '#ffffff',
            'font-size': 14,
            'text-valign': 'center',
            'text-halign': 'center',
            'shape': 'round-rectangle',
            'padding': '10px',
            'width': 'label',
            'height': 'label',
            'border-width': 1,
            'border-color': '#4a90e2'
          }
        },
        {
          selector: 'node[type="ontology"]',
          style: {
            'background-color': '#2ecc71',
            'label': 'data(label)',
            'color': '#ffffff',
            'font-size': 14,
            'text-valign': 'center',
            'text-halign': 'center',
            'shape': 'round-rectangle',
            'padding': '10px',
            'width': 'label',
            'height': 'label',
            'border-width': 1,
            'border-color': '#2ecc71'
          }
        },
        {
          selector: 'node[type="ontology_unclassified"]',
          style: {
            'background-color': '#7f8c8d',
            'label': 'data(label)',
            'color': '#ffffff',
            'font-size': 14,
            'text-valign': 'center',
            'text-halign': 'center',
            'shape': 'round-rectangle',
            'padding': '10px',
            'width': 'label',
            'height': 'label',
            'border-width': 2,
            'border-color': '#95a5a6',
            'border-style': 'dashed'
          }
        },
        {
          selector: 'edge[type="source"]',
          style: {
            'line-color': '#4a90e2',
            'width': 2,
            'curve-style': 'straight',
            'target-arrow-shape': 'triangle',
            'target-arrow-color': '#4a90e2'
          }
        },
        {
          selector: 'edge[type="mapping"]',
          style: {
            'line-color': '#9b59b6',
            'width': 2,
            'line-style': 'dashed',
            'curve-style': 'straight',
            'target-arrow-shape': 'triangle',
            'target-arrow-color': '#9b59b6'
          }
        },
        {
          selector: 'node[type="container"]',
          style: {
            'background-color': 'data(bgcolor)',
            'opacity': 0.15,
            'shape': 'round-rectangle',
            'width': 260,
            'height': 300,
            'text-valign': 'top',
            'font-size': 14,
            'font-weight': 'bold',
            'color': '#ffffff',
            'padding': '20px',
            'label': 'data(label)',
            'z-index': 0
          }
        },
        {
          selector: 'node[id="source_cloud"]',
          style: {
            'shape': 'ellipse',
            'width': 280,
            'height': 320,
            'background-color': '#4a90e2',
            'opacity': 0.12
          }
        }
      ],
      layout: { name: 'preset' }
    });

    cy.userZoomingEnabled(false);
    cy.userPanningEnabled(false);
    cy.boxSelectionEnabled(false);
    cy.zoom(1);
    cy.pan({ x: 50, y: 0 });
    cy.resize();

    cy.on('tap', 'node', async (evt) => {
      const id = evt.target.id();
      spotlightNode(id);
      const r = await fetch('/preview?node=' + encodeURIComponent(id));
      const data = await r.json();
      renderTable('preview_sources', data.sources);
      renderTable('preview_ontology', data.ontology);
    });
  }
  
  cy.elements().remove();
  
  if (sourceNodes.length > 0) {
    cy.add({
      group: "nodes",
      data: { id: "source_cloud", label: "Source Cloud", type: "container" },
      position: { x: CLOUD_X, y: 200 },
      style: {
        'shape': 'round-rectangle',
        'width': CLOUD_WIDTH,
        'height': CLOUD_HEIGHT,
        'background-color': '#ecf0f1',
        'background-image': 'url(https://upload.wikimedia.org/wikipedia/commons/3/3c/Cloud_icon.svg)',
        'background-fit': 'cover',
        'background-opacity': 0.15,
        'opacity': 0.35,
        'border-width': 2,
        'border-color': '#95a5a6',
        'text-valign': 'top',
        'text-halign': 'center',
        'font-size': 14,
        'font-weight': 'bold',
        'color': '#7f8c8d',
        'z-index': 0
      },
      locked: true
    });
  }
  
  if (ontologyNodes.length > 0) {
    cy.add({
      group: "nodes",
      data: { id: "unified_block", label: "Initech Corp.", type: "container" },
      position: { x: INITECH_X, y: 200 },
      style: {
        'shape': 'round-rectangle',
        'width': 340,
        'height': 300,
        'background-color': '#2ecc71',
        'background-image': 'url(https://upload.wikimedia.org/wikipedia/commons/3/33/Building_icon.svg)',
        'background-fit': 'cover',
        'background-opacity': 0.15,
        'opacity': 0.35,
        'border-width': 2,
        'border-color': '#27ae60',
        'text-valign': 'top',
        'text-halign': 'center',
        'font-size': 16,
        'font-weight': 'bold',
        'color': '#27ae60',
        'z-index': 0
      },
      locked: true
    });
  }
  
  cy.add(nodes);
  cy.add(edges);
  
  cy.nodes('[type!="container"]').forEach(node => {
    node.qtip({
      content: () => `<strong>${node.data('label')}</strong><br>Type: ${node.data('type')}`,
      position: { my: 'top center', at: 'bottom center' },
      style: { classes: 'qtip-light qtip-shadow' }
    });
  });
  
  cy.edges().forEach(edge => {
    edge.qtip({
      content: () => `Confidence: ${edge.data('confidence')}%`,
      position: { my: 'top center', at: 'bottom center' },
      style: { classes: 'qtip-dark qtip-shadow' }
    });
  });
  
  revealOntology();
  cy.pan({ x: 50, y: 0 });
  cy.zoom(1);
}

function renderTable(elId, tables){
  const el = document.getElementById(elId);
  if(!tables || Object.keys(tables).length===0) { el.innerHTML = "<div class='pill'>Click a node to preview data</div>"; return; }
  let html = "";
  for(const [name, rows] of Object.entries(tables)){
    if(!rows || rows.length==0){ continue; }
    const cols = Object.keys(rows[0]);
    html += `<div class='pill' style='margin:6px 0;'>${name}</div>`;
    html += "<table><thead><tr>" + cols.map(c=>`<th>${c}</th>`).join("") + "</tr></thead><tbody>";
    rows.forEach(r => { html += "<tr>" + cols.map(c=>`<td>${r[c]}</td>`).join("") + "</tr>"; });
    html += "</tbody></table>";
  }
  el.innerHTML = html || "<div class='pill'>No data</div>";
}

function renderPreviews(){
  renderTable('preview_sources', state.preview.sources);
  renderTable('preview_ontology', state.preview.ontology);
}
