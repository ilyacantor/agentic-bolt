function Skeleton({className=''}){ return <div className={`animate-pulse bg-slate-800/60 rounded-md ${className}`} />; }
